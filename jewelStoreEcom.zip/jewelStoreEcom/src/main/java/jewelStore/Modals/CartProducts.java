package jewelStore.Modals;

public class CartProducts {

	private
		int productId;
		int cartId;
		int qty;
		float price;
		float costPrice;
		int stock;
		String productImg;
		String productTitle;
		public int getProductId() {
			return productId;
		}
		public void setProductId(int productId) {
			this.productId = productId;
		}
		public int getCartId() {
			return cartId;
		}
		public void setCartId(int cartId) {
			this.cartId = cartId;
		}
		public int getQty() {
			return qty;
		}
		public void setQty(int qty) {
			this.qty = qty;
		}
		public float getPrice() {
			return price;
		}
		public void setPrice(float price) {
			this.price = price;
		}
		public String getProductImg() {
			return productImg;
		}
		public void setProductImg(String productImg) {
			this.productImg = productImg;
		}
		public String getProductTitle() {
			return productTitle;
		}
		public void setProductTitle(String productTitle) {
			this.productTitle = productTitle;
		}
		public int getStock() {
			return stock;
		}
		public void setStock(int stock) {
			this.stock = stock;
		}
		public float getCostPrice() {
			return costPrice;
		}
		public void setCostPrice(float costPrice) {
			this.costPrice = costPrice;
		}
}
