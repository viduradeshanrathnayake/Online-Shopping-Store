package jewelStore.Modals;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jewelStoreEcom.Cart.CartControl;
import jewelStoreEcom.Order.OrderProductsInterface;

public class OrderProducts implements OrderProductsInterface {

	private
	
	int orderId;
	int productId;
	int qty;
	float unit_sell_amount;
	float unit_cost_amount;
	int r;
	
	
	public OrderProducts(int orderId) {
		
		this.orderId = orderId;
	}
	
	public boolean createOrderProducts(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		
		CartControl cc = new CartControl();
		int cartId = (Integer) request.getSession().getAttribute("cartId");
		
		ArrayList<CartProducts> list = cc.getCartProducts(cartId);
		for (int i=0;i<list.size();i++) {
			
			CartProducts cp = list.get(i);
			if(cp.getStock() != 0) {
			setProductId(cp.getProductId());
			setQty(cp.getQty());
			setUnit_cost_amount(cp.getCostPrice());
			setUnit_sell_amount(cp.getPrice());
			
			String sql = "insert into order_product (quantity,unit_sell_price,unit_cost_price,product_id,order_id) values('"+getQty()+"','"+getUnit_sell_amount()+"','"+getUnit_cost_amount()+"','"+getProductId()+"','"+getOrderId()+"')";
			Database db = new Database();
			Statement st = db.getStatement();
			
			r = st.executeUpdate(sql);
			
			}
			
			}
		
		return true;

	}
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public float getUnit_sell_amount() {
		return unit_sell_amount;
	}
	public void setUnit_sell_amount(float unit_sell_amount) {
		this.unit_sell_amount = unit_sell_amount;
	}
	public float getUnit_cost_amount() {
		return unit_cost_amount;
	}
	public void setUnit_cost_amount(float unit_cost_amount) {
		this.unit_cost_amount = unit_cost_amount;
	}
	
	
	
}
