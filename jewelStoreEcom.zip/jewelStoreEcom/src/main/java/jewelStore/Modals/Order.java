package jewelStore.Modals;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jewelStoreEcom.Order.OrderInterface;

public class Order implements OrderInterface {

	private
		int orderId;
		String invoiceNo;
		Date orderDate;
		int orderStatus;
		float dueSellAmount;
		float dueCostAmount;
		int userId;
		int paymentId;
		String deliverAddress;
		int countOrder;
		String contact_no;
		
		public Order(int paymentId) {
			
			
			setPaymentId(paymentId);
			
		}
		
		public int createOrder(HttpServletRequest request,HttpServletResponse response) throws ClassNotFoundException, SQLException {
			
			setDeliverAddress((String) request.getSession().getAttribute("orderAddress"));
			setContact_no((String) request.getSession().getAttribute("orderPhone"));
			setOrderStatus(0);
			int cartId = (Integer) request.getSession().getAttribute("cartId");
			Cart c = new Cart(cartId);
			setDueCostAmount(c.getTotal().get(1));
			setDueSellAmount(c.getTotal().get(0));
			setUserId((Integer) request.getSession().getAttribute("userId"));
			
			Database db = new Database();
			Statement st = db.getStatement();
			String sql  = "insert into orders (invoice_no,order_date,order_status,due_sell_amount,due_cost_amount,user_id,payment_id,deliver_address,contact_no) values ('"+getInvoiceNo()+"',NOW(),'"+getOrderStatus()+"','"+getDueSellAmount()+"','"+getDueCostAmount()+"','"+getUserId()+"','"+getPaymentId()+"','"+getDeliverAddress()+"','"+getContact_no()+"')";
			int r = st.executeUpdate(sql, PreparedStatement.RETURN_GENERATED_KEYS);
			
			ResultSet rs = st.getGeneratedKeys();
			if(rs.next()) {
				
				setOrderId(rs.getInt(1));
			}
			
			return this.orderId;
		}
		
		public int getOrderId() {
			return orderId;
		}
		public void setOrderId(int orderId) {
			this.orderId = orderId;
		}
		public String getInvoiceNo() throws ClassNotFoundException, SQLException {
			
			Random rand = new Random();

			int  n = rand.nextInt(2000) + 1000;
			
			setInvoiceNo(this.userId+""+n+""+getCountOrder()+"J");  
			return invoiceNo;
		}
		public void setInvoiceNo(String invoiceNo) {
			
			this.invoiceNo = invoiceNo;
		}
		public Date getOrderDate() {
			
			
			return orderDate;
		}
		public void setOrderDate(Date orderDate) {
			this.orderDate = orderDate;
		}
		public int getOrderStatus() {
			return orderStatus;
		}
		public void setOrderStatus(int orderStatus) {
			this.orderStatus = orderStatus;
		}
		public float getDueSellAmount() {
			return dueSellAmount;
		}
		public void setDueSellAmount(float dueSellAmount) {
			this.dueSellAmount = dueSellAmount;
		}
		public float getDueCostAmount() {
			return dueCostAmount;
		}
		public void setDueCostAmount(float dueCostAmount) {
			this.dueCostAmount = dueCostAmount;
		}
		public int getUserId() {
			return userId;
		}
		public void setUserId(int userId) {
			this.userId = userId;
		}
		public int getPaymentId() {
			return paymentId;
		}
		public void setPaymentId(int paymentId) {
			this.paymentId = paymentId;
		}
		public String getDeliverAddress() {
			return deliverAddress;
		}
		public void setDeliverAddress(String deliverAddress) {
			this.deliverAddress = deliverAddress;
		}

		public int getCountOrder() throws ClassNotFoundException, SQLException {
			
			Database db = new Database();
			Statement st = db.getStatement();
			ResultSet r = st.executeQuery("select count(*) countOrder from orders where user_id='"+this.userId+"'");
			
			if(r.next()) {
				
				setCountOrder(r.getInt("countOrder"));
			}
			
			return countOrder;
		}

		public void setCountOrder(int countOrder) {
			this.countOrder = countOrder;
		}

		public String getContact_no() {
			return contact_no;
		}

		public void setContact_no(String contact_no) {
			this.contact_no = contact_no;
		}
	
	
}
