package jewelStore.Modals;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jewelStoreEcom.Payment.PaymentInterface;

public class Payment implements PaymentInterface {
	
	int paymentId;
	float payAmount;
	String cardNo;
	int cvCode;
	int expiryMonth;
	int expiryYear;
	Date paymentDate;



public int createPayment (HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
	
	Cart cart = new Cart((Integer) request.getSession().getAttribute("cartId"));
	setPayAmount(cart.getTotal().get(0));
	setCardNo(request.getParameter("cardNo"));
	setCvCode(Integer.valueOf(request.getParameter("cvCode")));
	setExpiryMonth(Integer.valueOf(request.getParameter("expiryMonth")));
	setExpiryYear(Integer.valueOf(request.getParameter("expiryYear")));
	
	String sql = "insert into payment (card_no,payment_date,expiry_month,expiry_year,amount,cvCode) values ('"+cardNo+"',NOW(),'"+expiryMonth+"','"+expiryYear+"','"+payAmount+"','"+cvCode+"')";
	Database db = new Database();
	Statement st = db.getStatement();
	//PreparedStatement ps = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
	
	int r = st.executeUpdate(sql,PreparedStatement.RETURN_GENERATED_KEYS);
	
	ResultSet rs = st.getGeneratedKeys();
	if(rs.next()) {
		
		paymentId = rs.getInt(1);
	}
	
	
	return this.paymentId;
	
	
}



public int getPaymentId() {
	return paymentId;
}



public void setPaymentId(int paymentId) {
	this.paymentId = paymentId;
}



public float getPayAmount() {
	return payAmount;
}



public void setPayAmount(float payAmount) {
	this.payAmount = payAmount;
}



public String getCardNo() {
	return cardNo;
}



public void setCardNo(String cardNo) {
	this.cardNo = cardNo;
}



public int getCvCode() {
	return cvCode;
}



public void setCvCode(int cvCode) {
	this.cvCode = cvCode;
}



public int getExpiryMonth() {
	return expiryMonth;
}



public void setExpiryMonth(int expiryMonth) {
	this.expiryMonth = expiryMonth;
}



public int getExpiryYear() {
	return expiryYear;
}



public void setExpiryYear(int expiryYear) {
	this.expiryYear = expiryYear;
}



public Date getPaymentDate() {
	return paymentDate;
}



public void setPaymentDate(Date paymentDate) {
	this.paymentDate = paymentDate;
}

}