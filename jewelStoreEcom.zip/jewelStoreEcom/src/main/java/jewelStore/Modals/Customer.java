package jewelStore.Modals;

import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jewelStoreEcom.Customer.CustomerInterface;
import jewelStoreEcom.Login.UserControl;

public class Customer extends User implements CustomerInterface {

	private
	
		int cartId;

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	
	public Customer() {
		
		
	}
	
	public Customer (int userId) throws ClassNotFoundException, SQLException {
		
		String sql = "select * "
				+ "from user NATURAL JOIN user_address NATURAL JOIN user_phone NATURAL JOIN cart "
				+ "where user_id = '"+userId+"'";
		Database db =new Database();
		Statement st = db.getStatement();
		ResultSet r = st.executeQuery(sql);
		r.next();
		this.userId = userId;
		this.email = r.getString("email");
		this.cartId = r.getInt("cart_id");
		this.fName = r.getString("first_name");
		this.lName = r.getString("last_name");
		this.userType = r.getInt("user_type");
		this.password = r.getString("password");
		
		address = new ArrayList<String>();
		phoneNo = new ArrayList<String>();
		while(r.next()) {
			
			if(address.contains(r.getString("address"))) {
				
				continue;
			}
			
			if(phoneNo.contains(r.getString("phone"))) {
				
				continue;
			}

			
			this.address.add(r.getString("address"));
			this.phoneNo.add(r.getString("phone"));
		}
		
		
	}
	
	public Customer addCustomer (HttpServletRequest request , HttpServletResponse response) throws ClassNotFoundException, SQLException, NoSuchAlgorithmException {
		
		UserControl uc = new UserControl();
		
		
		setfName(request.getParameter("fname"));
		setlName(request.getParameter("lname"));
		
		ArrayList<String> list = new ArrayList<String>();
		list.add(request.getParameter("address"));
		setAddress(list);
		
		ArrayList<String> list1 = new ArrayList<String>();
		list1.add(request.getParameter("phone"));
		setPhoneNo(list1);
		
		setEmail(request.getParameter("email"));
		setPassword(uc.MD5(request.getParameter("password")));
		//setPassword(request.getParameter("password"));
		
		setUserType(0);
		
		Database db = new Database();
		Statement st = db.getStatement();
		String sqlUser = "insert into user (first_name,last_name,email,password,user_type,delete_user) values ('"+fName+"','"+lName+"','"+email+"','"+password+"','"+userType+"','0')";
		int r = st.executeUpdate(sqlUser, PreparedStatement.RETURN_GENERATED_KEYS);
		
		ResultSet rs = st.getGeneratedKeys();
		if(rs.next()) {
			
			setUserId(rs.getInt(1));
			int r3 = st.executeUpdate("insert into cart (user_id) values ('"+this.userId+"') ",PreparedStatement.RETURN_GENERATED_KEYS);
			
			ResultSet st1 = st.getGeneratedKeys();
			if(st1.next()) {
				
				setCartId(st1.getInt(1));
			}

			for(int j=0;j<address.size();j++) {
				
			int r1 = st.executeUpdate("insert into user_address (address,user_id) values('"+address.get(j)+"','"+this.userId+"') ");
			
			}
			
			for(int j=0;j<phoneNo.size();j++) {
				
				int r2 = st.executeUpdate("insert into user_phone (phone,user_id) values('"+phoneNo.get(j)+"','"+this.userId+"') ");

			}
		}
		
		
		return this;
	}
	
	
	

}
