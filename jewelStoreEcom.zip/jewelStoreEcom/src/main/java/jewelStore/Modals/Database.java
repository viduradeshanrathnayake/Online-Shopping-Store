package jewelStore.Modals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

	private
	 	Connection con ;
		Statement st;
		
	public Statement getStatement() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sliit_ecom", "root", "");
		st = con.createStatement();
		
		return st;
		
		
		
	}
	
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sliit_ecom", "root", "");
		
		return con;
	}
	
}
