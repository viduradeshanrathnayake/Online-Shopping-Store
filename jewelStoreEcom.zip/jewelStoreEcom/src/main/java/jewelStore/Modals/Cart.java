package jewelStore.Modals;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Cart {

	int cartId;
	int userId;
	int cartCount;
	ArrayList<Float> total;
	
	public Cart(int cartId) {
		
		this.cartId = cartId;
	}
	
	public int getCartCount() throws ClassNotFoundException, SQLException {
		
		Database db = new Database();
		Statement s = db.getStatement();
		ResultSet r = s.executeQuery("select count(*) as count_cart from cart_product where cart_id = '"+cartId+"'");
		r.next();
		return r.getInt("count_cart");
	}

	public ArrayList<Float> getTotal() throws ClassNotFoundException, SQLException {
		
		Database db = new Database();
		Statement s = db.getStatement();
		String sql = "select sum(quantity*sell_price) as cartTotalSell , sum(quantity*cost_price) as cartTotalCost "
				+ "from cart_product T1 INNER JOIN products T2 ON T1.product_id=T2.product_id "
				+ "where cart_id='"+cartId+"'";
		ResultSet r = s.executeQuery(sql);
		r.next();
		total = new ArrayList<Float>();
		this.total.add(r.getFloat("cartTotalSell"));
		this.total.add(r.getFloat("cartTotalCost"));

		return total;
	}

	public void setTotal(ArrayList<Float> total) {
		this.total = total;
	}
	
}
