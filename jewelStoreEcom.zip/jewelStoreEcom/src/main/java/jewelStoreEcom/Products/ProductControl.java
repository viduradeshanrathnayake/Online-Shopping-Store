package jewelStoreEcom.Products;

import jewelStore.Modals.Product;

import java.sql.*;
import java.util.ArrayList;

public class ProductControl {
	
	public ArrayList<Product> getProducts() throws SQLException, ClassNotFoundException {
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sliit_ecom", "root", "");
		Statement st = con.createStatement();
		  ResultSet r = st.executeQuery("select * from products");
			 ArrayList<Product> arrayList = new ArrayList<Product>();
while(r.next()) {
			 
			 Product x = new Product();
			 
			 x.setProductId(r.getInt("product_id"));
			 x.setCatId(r.getInt("cat_id"));
			 x.setCostPrice(r.getFloat("cost_price"));
			 x.setSellPrice(r.getFloat("sell_price"));
			 x.setProDesc(r.getString("product_desc"));
			 x.setProductName(r.getString("product_title"));
			 x.setProKeywords(r.getString("product_keywords"));
			 x.setProductImg(r.getString("product_img"));
			 x.setStock(r.getInt("stock"));
			 
			 arrayList.add(x);
			 
			 
			 
			 
			 
		 }
		return arrayList;
		 
		
	}
public Product getDet(int product_id) throws ClassNotFoundException, SQLException {
	
	Class.forName("com.mysql.jdbc.Driver");
	
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sliit_ecom", "root", "");
		Statement st = con.createStatement();
		ResultSet r = st.executeQuery("select * from products where product_id='"+product_id+"'");
		 Product x = new Product();
	  while(r.next()) {
			 
			 
			 x.setProductId(r.getInt("product_id"));
			 x.setCatId(r.getInt("cat_id"));
			 x.setCostPrice(r.getFloat("cost_price"));
			 x.setSellPrice(r.getFloat("sell_price"));
			 x.setProDesc(r.getString("product_desc"));
			 x.setProductName(r.getString("product_title"));
			 x.setProKeywords(r.getString("product_keywords"));
			 x.setProductImg(r.getString("product_img"));
			 x.setStock(r.getInt("stock"));
			 
		 }
	  
	
	return x;
}

}
