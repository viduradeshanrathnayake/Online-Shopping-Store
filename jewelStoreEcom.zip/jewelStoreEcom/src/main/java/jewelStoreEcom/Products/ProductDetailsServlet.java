package jewelStoreEcom.Products;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jewelStore.Modals.Product;



/**
 * Servlet implementation class ProductDetailsServlet
 */
@WebServlet("/product/*")
public class ProductDetailsServlet extends HttpServlet {
	
	
	
	private static final long serialVersionUID = 1L;
	private int p_id;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	ProductControl p = new ProductControl();
	Product pro = new Product();
	private 
	
	StringBuffer url;
	String url_str;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		url = request.getRequestURL();
		url_str = url.toString();
		String[] parts = url_str.split("/");
		p_id = Integer.parseInt(parts[parts.length-1]);
		try {
			pro = p.getDet(this.p_id);
			if(pro.getProductId() == 0) {
				
				response.sendRedirect("/index");

			}
			else {
			request.setAttribute("details", pro);
			request.getRequestDispatcher("/WEB-INF/views/ProductDetails.jsp").forward(request, response);
			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

}
