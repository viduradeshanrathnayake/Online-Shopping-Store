package jewelStoreEcom.Payment;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jewelStore.Modals.Order;
import jewelStore.Modals.OrderProducts;
import jewelStore.Modals.Payment;
import jewelStoreEcom.Cart.CartControl;
import jewelStoreEcom.Order.OrderInterface;
import jewelStoreEcom.Order.OrderProductsInterface;

/**
 * Servlet implementation class PaymentServlet
 */
@WebServlet("/payment")
public class PaymentServlet extends HttpServlet {
	
	private
	int success;
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/*** 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.sendRedirect("/index");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getParameter("phone") != null) {
			
				request.getRequestDispatcher("/WEB-INF/views/Payment.jsp").forward(request, response);
	
		}
		
		else {
			PaymentInterface p = new Payment();
			try {
			int paymentId = p.createPayment(request, response);
			OrderInterface order = new Order(paymentId);
			int orderId = order.createOrder(request, response);
			OrderProductsInterface op = new OrderProducts(orderId);
			if(op.createOrderProducts(request, response)) {
				
				success = 1;
				CartControl cc =new CartControl();
				cc.clearCart((Integer) request.getSession().getAttribute("cartId"));
				
			}
			else {
				
				success = 0;
				
			}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.getSession().setAttribute("success", success);
			request.getRequestDispatcher("/WEB-INF/views/Success.jsp").forward(request, response);
			
		}
		
	}

}
