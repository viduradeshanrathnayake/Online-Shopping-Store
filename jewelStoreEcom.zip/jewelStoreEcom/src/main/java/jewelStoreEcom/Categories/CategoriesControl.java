package jewelStoreEcom.Categories;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import jewelStore.Modals.Categories;

public class CategoriesControl {

	public ArrayList<Categories> getCats() throws SQLException, ClassNotFoundException{
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sliit_ecom", "root", "");
		Statement st = con.createStatement();
		  ResultSet r = st.executeQuery("select * from categories");
		  
		  ArrayList<Categories> list = new ArrayList<Categories>();
		  while(r.next()) {
			  
			  Categories c = new Categories();
			  c.setCatId(r.getInt("cat_id"));
			  c.setCatTitle(r.getString("cat_title"));
			  c.setCatDesc(r.getString("cat_description"));
			  
			  list.add(c);
		  }
		  
		  return list;
	}
}
