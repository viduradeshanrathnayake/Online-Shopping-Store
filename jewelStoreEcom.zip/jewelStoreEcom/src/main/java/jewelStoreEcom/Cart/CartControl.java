package jewelStoreEcom.Cart;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import jewelStore.Modals.Cart;
import jewelStore.Modals.CartProducts;
import jewelStore.Modals.Database;

public class CartControl {
	
	private ResultSet r;

	public ArrayList<CartProducts> getCartProducts(int cartId) throws SQLException, ClassNotFoundException{
		
		Database db =new Database();
		Statement st = db.getStatement();
		  r = st.executeQuery("select T1.cart_id,T1.quantity,T2.* from cart_product T1 INNER JOIN products T2 ON T1.product_id = T2.product_id where T1.cart_id='"+cartId+"'");
		  ArrayList<CartProducts> list = new ArrayList<CartProducts>();
		  while(r.next()) {
			  
			  CartProducts cp = new CartProducts();
			  cp.setProductId(r.getInt("product_id"));
			  cp.setCartId(r.getInt("cart_id"));
			  cp.setPrice(r.getFloat("sell_price"));
			  cp.setCostPrice(r.getFloat("cost_price"));
			  cp.setQty(r.getInt("quantity"));
			  cp.setProductImg(r.getString("product_img"));
			  cp.setProductTitle(r.getString("product_title"));
			  cp.setStock(r.getInt("stock"));
			  
			  list.add(cp);
		  }
		  
		  return list;
	}
	
	public int addToCart(int productId,int cartId,int qty) throws SQLException, ClassNotFoundException{
		
		Database db =new Database();
		Statement st = db.getStatement();
		
		 r = st.executeQuery("select count(*) as check_cart,quantity  from cart_product where cart_id='"+cartId+"' AND product_id='"+productId+"'");
		 r.next();
		 if(r.getInt("check_cart") != 0) {
			 
			 qty += r.getInt("quantity");
			 
		 int r3 = st.executeUpdate("update cart_product set quantity='"+qty+"' where cart_id='"+cartId+"' AND product_id='"+productId+"'");

		 }
		 
	 else {

		int r1 = st.executeUpdate("INSERT INTO cart_product (quantity,product_id,cart_id)" + "VALUES ('"+qty+"','"+productId+"','"+cartId+"')");

	 }
		 
		 r = st.executeQuery("select count(*) as cart_count from cart_product where cart_id='"+cartId+"'");
		 r.next();
		 int cart_count = r.getInt("cart_count");
	
		  return cart_count;

}
	
	public int deleteCartProduct(int productId,int cartId) throws ClassNotFoundException, SQLException {
		
		Database db = new Database();
		Statement st = db.getStatement();
		int r = st.executeUpdate("delete from cart_product where cart_id='"+cartId+"' AND product_id = '"+productId+"'");
		Cart c = new Cart(cartId);
		return c.getCartCount();
	}
	
	public void updateCartQty(int productId,int cartId,int qty) throws ClassNotFoundException, SQLException {
		
		Database db = new Database();
		Statement st = db.getStatement();
		int r = st.executeUpdate("update cart_product set quantity='"+qty+"' where cart_id='"+cartId+"' AND product_id = '"+productId+"'");
		
	}
	
	public void clearCart(int cartId) throws ClassNotFoundException, SQLException {
		
		Database db = new Database();
		Statement st = db.getStatement();
		int r = st.executeUpdate("delete from cart_product where cart_id='"+cartId+"'");
		
	}
}

