package jewelStoreEcom.Cart;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet("/cart")
public class CartServlet extends HttpServlet {
	private 
	int count;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getSession().getAttribute("userId") == null) {
			
			request.getSession().setAttribute("redirectUrl", "/cart");
			response.sendRedirect("/login");

		}
		else {
			CartControl cc = new CartControl();
			
			try {
				int cartId = (int) request.getSession().getAttribute("cartId");
				request.setAttribute("cart", cc.getCartProducts(cartId));
				request.getRequestDispatcher("/WEB-INF/views/cart.jsp").forward(request, response);

			
			} catch (NumberFormatException | ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		if(request.getParameter("productId") != null) {
		
		String p_id = request.getParameter("productId");
		String qty = request.getParameter("qty");
		if(request.getSession().getAttribute("cartId") == null) {
			request.getSession().setAttribute("redirectUrl", "/product/"+p_id);
			response.getWriter().write("");
		}
		else {
		int cartId = (int) request.getSession().getAttribute("cartId");
		CartControl cc = new CartControl();
		
			try {
				this.count = cc.addToCart(Integer.parseInt(p_id),cartId,Integer.parseInt(qty));
				
				System.out.println("Wede hari");
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("sql awul");
				e.printStackTrace();
			}
	
		response.getWriter().write(Integer.toString(count));
		}
		
		}
		
		if(request.getParameter("product_id") != null) {
			
			int cartId = (int) request.getSession().getAttribute("cartId");
			int productId = Integer.parseInt(request.getParameter("product_id")) ;
			
			CartControl cc = new CartControl();
			try {
				int count = cc.deleteCartProduct(productId, cartId);
				response.getWriter().write(Integer.toString(count));
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		if(request.getParameter("p_id") != null) {
			
			int cartId = (int) request.getSession().getAttribute("cartId");
			int productId = Integer.parseInt(request.getParameter("p_id")) ;
			int qty = Integer.parseInt(request.getParameter("qty")) ;
			
			CartControl cc = new CartControl();
			try {
				cc.updateCartQty(productId, cartId, qty);
				response.getWriter().write("Cart Updated");
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
	}

}
