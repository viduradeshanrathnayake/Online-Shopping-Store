package jewelStoreEcom.Register;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jewelStore.Modals.Customer;
import jewelStoreEcom.Customer.CustomerInterface;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.getRequestDispatcher("/WEB-INF/views/Register.jsp").forward(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		CustomerInterface ci = new Customer();
		try {
			//ci.addCustomer(request, response);
			Customer c1 = ci.addCustomer(request, response);
			request.getSession().setAttribute("userId", c1.getUserId());
			request.getSession().setAttribute("email", c1.getEmail());
			request.getSession().setAttribute("fName", c1.getfName());
			request.getSession().setAttribute("lName", c1.getlName());
			request.getSession().setAttribute("cartId", c1.getCartId());
			request.getSession().setAttribute("address", c1.getAddress());
			request.getSession().setAttribute("phone", c1.getPhoneNo());
			
			response.sendRedirect("/index");
		} catch (ClassNotFoundException | SQLException | NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
