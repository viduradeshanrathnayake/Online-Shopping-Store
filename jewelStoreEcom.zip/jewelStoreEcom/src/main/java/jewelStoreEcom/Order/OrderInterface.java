package jewelStoreEcom.Order;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface OrderInterface {

	public int createOrder(HttpServletRequest request , HttpServletResponse reponse) throws ClassNotFoundException, SQLException;
}
