package jewelStoreEcom.Order;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface OrderProductsInterface {

	public boolean createOrderProducts(HttpServletRequest request,HttpServletResponse response) throws ClassNotFoundException, SQLException;
}
