package jewelStoreEcom.Login;

import jewelStore.Modals.Customer;
import jewelStore.Modals.Database;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;



public class UserControl {
	
	public String MD5(String md5) throws NoSuchAlgorithmException {
		
		MessageDigest m = MessageDigest.getInstance("MD5");
        m.update(md5.getBytes(),0,md5.length());
        return new BigInteger(1,m.digest()).toString(16);

		
		}

	public Customer getUser(String email,String password) throws SQLException, ClassNotFoundException, NoSuchAlgorithmException {
		String hashPass = MD5(password);
		Database db = new Database();	
		Statement st = db.getStatement();
		  ResultSet r = st.executeQuery("select user_id,count(*) AS rowcount from user where email='"+email+"' AND password = '"+hashPass+"'");
			r.next();
			int count = r.getInt("rowcount");
			
			
			if(count == 0) {
				
				Customer c1 = new Customer();
				c1.setAvailable(false);
				return c1;
				
			}
			
			else {
				
				Customer c2 = new Customer(r.getInt("user_id")) ;			
				c2.setAvailable(true);
				return c2;



			}
		
		
		
		
	}
}
