package jewelStoreEcom.Login;


import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jewelStore.Modals.Customer;

/**
 * Servlet implementation class LoginServlet
 */

@WebServlet(urlPatterns = "/login")


public class LoginServlet extends HttpServlet {
	
	
	private 
	
		Customer c1;
	String email;
	String password;
	String redirect_url;
		
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// TODO Auto-generated method stub
		if(request.getSession().getAttribute("userId") == null) {
		request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request,response);
		}
		
		else {
			
			response.sendRedirect("/index");

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		email = request.getParameter("email");
		password = request.getParameter("password");
		if(request.getSession().getAttribute("redirectUrl") != null) {
		redirect_url = (String) request.getSession().getAttribute("redirectUrl");
		}
		else {
		
			redirect_url = "/index";
			
		}
		UserControl u1 = new UserControl();
		try {
			try {
				c1 = u1.getUser(email, password);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(c1.getAvailable())
		{
			
			request.getSession().setAttribute("userId", c1.getUserId());
			request.getSession().setAttribute("email", c1.getEmail());
			request.getSession().setAttribute("fName", c1.getfName());
			request.getSession().setAttribute("lName", c1.getlName());
			request.getSession().setAttribute("cartId", c1.getCartId());
			request.getSession().setAttribute("address", c1.getAddress());
			request.getSession().setAttribute("phone", c1.getPhoneNo());
			
			response.sendRedirect(redirect_url);

		}
		else {
			
			response.sendRedirect("/login");

		}
		
	}

}
