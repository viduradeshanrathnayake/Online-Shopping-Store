package jewelStoreEcom.Customer;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jewelStore.Modals.Customer;

public interface CustomerInterface {

	public Customer addCustomer(HttpServletRequest request,HttpServletResponse response) throws ClassNotFoundException, SQLException, NoSuchAlgorithmException;
}
